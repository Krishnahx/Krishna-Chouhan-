export * from "./colors";
export * from "./GlobalStyles.styled";
export * from "./scroll";
export * from "./typography";
